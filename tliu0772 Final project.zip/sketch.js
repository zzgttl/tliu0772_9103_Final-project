let flowers = [];
let dots = [];
let grass = [];

let numFlowers = 4;
let numDots = 400;
let grassNum = 60;

let song;
let fft;
let numBins = 128;
let smoothing = 0.8;
let button;

let flowerSound;
let dotSound;

function preload() {
  song = loadSound("assets/music.mp3");
  flowerSound = loadSound("assets/flower.mp3");
  dotSound = loadSound("assets/dot.mp3");
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB);
  angleMode(DEGREES);

  fft = new p5.FFT(smoothing, numBins);
  song.connect(fft);

  button = createButton("Play/Pause");
  button.position((width - button.width) / 2, height - button.height - 2);
  button.mousePressed(play_pause);

  initialiseFlowers();
  initialiseDots();
  initialiseGrass();
}

function draw() {
  background(38, 97, 91);
  angleMode(DEGREES);

  let spectrum = fft.analyze();

  for (let i = 0; i < flowers.length; i++) {
    flowers[i].display(spectrum[i % numBins] / 255);
  }

  for (let i = 0; i < dots.length; i++) {
    dots[i].display(spectrum[i % numBins] / 255);
  }

  drawGrass();
}

function play_pause() {
  if (song.isPlaying()) {
    song.stop();
  } else {
    song.loop();
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  button.position((width - button.width) / 2, height - button.height - 2);
  initialiseFlowers();
  initialiseDots();
  initialiseGrass();
}

function mouseMoved() {
  // Map the mouse X coordinate to the pan value (range -1 to 1)
  let pan = map(mouseX, 0, width, -1, 1);
  song.pan(pan);

  // Map the mouse Y coordinate to the volume value (range 0 to 1)
  let volume = map(mouseY, height, 0, 0, 1);
  song.setVolume(volume);
}

function mousePressed() {
  for (let flower of flowers) {
    flower.clicked(mouseX, mouseY);
  }
  for (let dot of dots) {
    dot.clicked(mouseX, mouseY);
  }
}

function initialiseFlowers() {
  flowers = [];
  flowers.push(new Flower(width / 4, height / 3, 22, 0, flowerSound));
  flowers.push(new Flower(width / 10 * 9, height / 10, 8, 1, flowerSound));
  flowers.push(new Flower(width + 75, height / 10 * 6, 9, 2, flowerSound));
  flowers.push(new Flower(width / 2, height / 2, 20, 3, flowerSound));
  flowers.push(new Flower((width / 10) * 7, 0, 20, 3, flowerSound));
  flowers.push(new Flower(0, height, 20, 3, flowerSound));
  flowers.push(new Flower(width / 10 * 7, height / 10 * 8.5, 20, 4, flowerSound));
  flowers.push(new Flower(width / 5, height / 10 * 9, 5, 5, flowerSound));
  flowers.push(new Flower(-170, height / 2, 8, 6, flowerSound));

  if (width > 1000 && height > 1000) {
    for (let i = 0; i < numFlowers; i++) {
      let flower = new Flower(random(width), random(height), floor(random(18, 25)), floor(random(2, 5)), flowerSound);
      flowers.push(flower);
    }
  }
}

function initialiseDots() {
  dots = [];
  if (width > 1000 && height > 1000) {
    numDots += 300;
  }
  for (let i = 0; i < numDots; i++) {
    let dot = new Dot(random(width), random(height), Math.floor(random(0, 3)), dotSound);
    dots.push(dot);
  }
}

function initialiseGrass() {
  grass = [];
  if (width > 1000 || height > 1000) {
    grassNum += 20;
  }
  for (let i = 0; i < grassNum; i++) {
    let posy = random(height);
    let posx = random(width);
    let diffY = random(-5, 5);
    let diffX = random(-5, 5);

    if (i < grassNum / 4) {
      grass.push({ x1: 0, y1: posy, x2: 15, y2: posy + diffY });
    } else if (i >= grassNum / 4 && i < grassNum / 2) {
      grass.push({ x1: width, y1: posy, x2: width - 15, y2: posy + diffY });
    } else if (i >= grassNum / 2 && i < 3 * grassNum / 4) {
      grass.push({ x1: posx, y1: 0, x2: posx + diffX, y2: 15 });
    } else {
      grass.push({ x1: posx, y1: height, x2: posx + diffX, y2: height - 15 });
    }
  }
}

function drawGrass() {
  for (let i = 0; i < grassNum; i++) {
    let blade = grass[i];
    strokeWeight(12);
    stroke(color(0, 75, 65));
    line(blade.x1, blade.y1, blade.x2, blade.y2);
  }
}
