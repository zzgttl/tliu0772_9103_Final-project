class Dot {
  constructor(x, y, colourNum) {
    this.x = x;
    this.y = y;
    this.colourNum = colourNum;
    switch (this.colourNum) {
      case 0:
        this.colour = color(350, 25, 100);
        break;
      case 1:
        this.colour = color(0, 0, 0);
        break;
      case 2:
        this.colour = color(0, 100, 55);
        break;
    }
  }

  display(scale = 1) {
    push();
    strokeWeight(8 * scale);
    stroke(this.colour);
    fill(this.colour);
    circle(this.x, this.y, 20 * scale);
    pop();
  }
}
