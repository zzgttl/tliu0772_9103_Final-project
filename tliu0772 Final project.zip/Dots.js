class Dot {
  constructor(x, y, colourNum, sound) {
    this.x = x;
    this.y = y;
    this.colourNum = colourNum;
    this.sound = sound;
    switch (this.colourNum) {
      case 0:
        this.colour = color(350, 25, 100);
        break;
      case 1:
        this.colour = color(0, 0, 0);
        break;
      case 2:
        this.colour = color(0, 100, 55);
        break;
    }
  }

  display(scale = 1, hueShift = 0) {
    push();
    let hueValue = (hue(this.colour) + hueShift) % 360;
    this.currentColour = color(hueValue, saturation(this.colour), brightness(this.colour));
    
    strokeWeight(8 * scale);
    stroke(this.currentColour);
    fill(this.currentColour);
    circle(this.x, this.y, 10 * scale);
    pop();
  }

  clicked(mx, my) {
    let d = dist(mx, my, this.x, this.y);
    if (d < 10) { // Assuming the clickable area is within a 10-pixel radius
      this.sound.play();
    }
  }
}
