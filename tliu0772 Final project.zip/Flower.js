class Flower {
  constructor(x, y, leaveNumber, shape, sound) {
    this.x = x;
    this.y = y;
    this.leaveNumber = leaveNumber;
    this.shape = shape;
    this.sound = sound;
    this.colours = [];
    for (let i = 0; i < this.leaveNumber; i++) {
      let colourNum = Math.floor(random(0, 2));
      switch (colourNum) {
        case 0:
          this.colours.push(color(341, 60, 79));
          break;
        case 1:
          this.colours.push(color(338, 48, 9));
          break;
      }
    }
  }

  display(scale = 1, hueShift = 0) {
    push();
    translate(this.x, this.y);
    for (let e = 1; e < this.leaveNumber; e++) {
      let newHue = (hue(this.colours[e]) + hueShift) % 360;
      strokeWeight(12 * scale);
      stroke(color(newHue, saturation(this.colours[e]), brightness(this.colours[e])));
      noFill();
      switch (this.shape) {
        case 0:
          curve(-900 + 100 * e, -700, 0, 0, 400 - e * 25, -300, -400 + e * 40, -300);
          break;
        case 1:
          curve(-50 * e, 200, 0, 0, -60 - 5 * e, -100 + 30 * e, -600 + 100 * e, 200);
          break;
        case 2:
          curve(60 * e, -300 * e, 0, 0, -190 - 12 * e, -380 + 40 * e, 450 * 0.3, 100 * 0.8);
          break;
        case 3:
          curve(200, 200, 0, 0, cos(e * 55) * 100, sin(e * 55) * 100, 200, 100);
          break;
        case 4:
          curve(-200, -200, 0, 0, -sin(e * 25) * 100, -100 * sin(e * 28), -200, -100);
          break;
        case 5:
          line(0, 0, 200, -200);
          curve(200, -200, 40 * e, -40 * e, 80 + 20 * e, -200 - 5 * e, 300 + 30 * e, -500);
          curve(200, 0, 40 * e, -40 * e, 100 + 30 * e, -50 - 25 * e, 500, -500);
          break;
        case 6:
          curve(2 * (-60 * e), 2 * (300 * e), 2 * 0, 2 * 0, 2 * (-190 - 12 * e), 2 * (-380 + 40 * e), 2 * (0.3 + 450), 2 * (0.8 + 100));
          break;
      }
    }
    pop();
  }

  clicked(mx, my) {
    let d = dist(mx, my, this.x, this.y);
    if (d < 100) { // Assuming the clickable area is within a 100-pixel radius
      this.sound.play();
    }
  }
}
